/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.entradaexpress;

public class EntradaExpress {

    public static void main(String[] args) {
        var home = new FormHome();
        home.setVisible(true);
    }
}
